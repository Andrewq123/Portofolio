package md.andrei.portfolio;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicLong;

/** Counts page views (GET requests, not css/js) and shares the number with every JSP as ${applicationScope.views}. */
@WebFilter("/*")
public class ViewCounterFilter implements Filter {
    private final AtomicLong views = new AtomicLong();

    @Override
    public void init(FilterConfig config) {
        config.getServletContext().setAttribute("views", views);
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        if (req instanceof HttpServletRequest r && "GET".equals(r.getMethod())) {
            String p = r.getServletPath();
            if (!p.startsWith("/css") && !p.startsWith("/js")) views.incrementAndGet();
        }
        chain.doFilter(req, res);
    }
}
