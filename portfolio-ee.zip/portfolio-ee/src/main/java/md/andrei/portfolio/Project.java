package md.andrei.portfolio;

import java.util.List;

public class Project {
    private final String title, summary, status, year;
    private final List<String> tags;

    public Project(String title, String summary, String status, String year, List<String> tags) {
        this.title = title; this.summary = summary; this.status = status; this.year = year; this.tags = tags;
    }
    public String getTitle() { return title; }
    public String getSummary() { return summary; }
    public String getStatus() { return status; }
    /** Year built, or "" if not filled in yet. */
    public String getYear() { return year; }
    public List<String> getTags() { return tags; }
}
