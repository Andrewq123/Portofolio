package md.andrei.portfolio;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.regex.Pattern;

@WebServlet("/contact")
public class ContactServlet extends HttpServlet {
    private static final Logger LOG = Logger.getLogger(ContactServlet.class.getName());
    private static final Pattern EMAIL = Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");
    private static final String VIEW = "/WEB-INF/views/contact.jsp";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session != null && session.getAttribute("flash") != null) {
            req.setAttribute("flash", session.getAttribute("flash"));
            session.removeAttribute("flash");
        }
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String name = clean(req.getParameter("name"));
        String email = clean(req.getParameter("email"));
        String message = clean(req.getParameter("message"));

        List<String> errors = new ArrayList<>();
        if (name.isEmpty() || name.length() > 80) errors.add("Enter your name (up to 80 characters).");
        if (email.length() > 120 || !EMAIL.matcher(email).matches()) errors.add("Enter a valid email address.");
        if (message.length() < 10 || message.length() > 1000) errors.add("Write a message of 10 to 1000 characters.");

        if (!errors.isEmpty()) {
            req.setAttribute("errors", errors);
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            req.getRequestDispatcher(VIEW).forward(req, resp);
            return;
        }
        LOG.info("Contact message from " + name + " <" + email + ">: " + message);
        req.getSession().setAttribute("flash", "Thanks, " + name + ". Your message was received.");
        resp.sendRedirect(req.getContextPath() + "/contact"); // post-redirect-get
    }

    /** Trims and flattens line breaks so a message cannot forge extra log lines. */
    private static String clean(String s) {
        return s == null ? "" : s.strip().replaceAll("[\\r\\n]+", " ");
    }
}
