package md.andrei.portfolio;

import java.util.List;

/**
 * In-memory data for now. Replace with a JDBC/JPA database later.
 * EDIT HERE: put the real year in the 4th argument of each project (for example "2024"). An empty "" hides the year.
 */
public final class ProjectRepository {
    private ProjectRepository() {}

    public static List<Project> all() {
        return List.of(
            new Project("Web games",
                "Games that run in the browser, built with HTML, CSS and JavaScript.",
                "Built", "", List.of("Games", "Web", "JavaScript")),
            new Project("Console games",
                "Games that run in the terminal.",
                "Built", "", List.of("Games", "Console")),
            new Project("Schedule app",
                "An application written in Java for planning a schedule.",
                "Built", "", List.of("Java", "Application")),
            new Project("PYRO",
                "One of my own applications.",
                "Built", "", List.of("Application")),
            new Project("JARVIS-style AI assistant",
                "My own AI assistant project, inspired by JARVIS.",
                "Built", "", List.of("AI", "Application")),
            new Project("Bug report: a real website, tested",
                "Test forms and layouts on phone and desktop. Each defect gets steps, expected result and actual result.",
                "In progress", "", List.of("QA", "Manual testing")),
            new Project("Python test script",
                "Checks a set of pages or inputs automatically and prints a pass/fail report.",
                "Up next", "", List.of("Python", "QA", "Automation")),
            new Project("This portfolio",
                "Servlets, JSP and JSTL on the back end, plain HTML, CSS and JavaScript on the front end.",
                "Live", "", List.of("Java", "Java EE", "JSP", "Servlets")));
    }
}
