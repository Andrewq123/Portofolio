<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Play"/><c:set var="active" value="play"/><c:set var="hero" value="https://images.unsplash.com/photo-1585412168334-8fa91429cc64?auto=format&fit=crop&w=1800&q=70"/>
<%@ include file="/WEB-INF/jspf/header.jspf" %>
<div class="hero">
  <img class="hero-img" src="${hero}" alt="">
  <div class="hero-text"><h1>Play</h1><p class="lead">Two small things made for fun: a bug-squashing game and a tiny assistant.</p></div>
</div>
<main class="wrap">
  <h2>Bug Squash</h2>
  <p class="note">Click the bugs before they move. You have 30 seconds.</p>
  <div class="bar">
    <span>Score: <strong id="score">0</strong></span><span>Time: <strong id="time">30</strong></span><span>Best: <strong id="best">0</strong></span>
    <button id="start" type="button">Start</button>
  </div>
  <div id="arena" class="arena" role="group" aria-label="Bug Squash board"></div>

  <h2>Ask JARVIS-lite</h2>
  <p class="note">A small demo written for this site. It only knows a few commands, so type <em>help</em>.</p>
  <div class="term">
    <div id="term-out" aria-live="polite"></div>
    <form id="term-form" autocomplete="off">
      <label for="term-in" class="sr">Command</label><span aria-hidden="true">&gt;</span>
      <input id="term-in" maxlength="40" placeholder="type a command">
    </form>
  </div>
</main>
<%@ include file="/WEB-INF/jspf/footer.jspf" %>
