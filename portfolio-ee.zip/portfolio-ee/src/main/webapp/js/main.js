// Theme: dark by default ("lights off"), light mode remembered in the browser
(function () {
  var root = document.documentElement, btn = document.getElementById('theme'), saved = null;
  try { saved = localStorage.getItem('theme'); } catch (e) {}
  var light = saved === 'light';
  function apply() {
    root.setAttribute('data-theme', light ? 'light' : 'dark');
    if (btn) { btn.setAttribute('aria-pressed', light); btn.textContent = light ? 'Lights off' : 'Lights on'; }
  }
  apply();
  if (btn) btn.addEventListener('click', function () {
    light = !light; apply();
    try { localStorage.setItem('theme', light ? 'light' : 'dark'); } catch (e) {}
  });
})();

// Home: animated skills test run
(function () {
  var btn = document.getElementById('go');
  if (!btn) return;
  var rows = document.querySelectorAll('#tests li');
  btn.addEventListener('click', function () {
    btn.disabled = true;
    rows.forEach(function (r) { r.removeAttribute('data-s'); r.lastElementChild.textContent = 'running'; });
    var i = 0;
    (function next() {
      if (i >= rows.length) { btn.disabled = false; btn.textContent = 'Run again'; return; }
      var r = rows[i++], ok = r.getAttribute('data-r') === 'pass';
      setTimeout(function () {
        r.setAttribute('data-s', ok ? 'pass' : 'learn');
        r.lastElementChild.textContent = ok ? 'PASS' : 'LEARNING';
        next();
      }, 420);
    })();
  });
})();

// Projects: filter by tag
(function () {
  var chips = document.querySelectorAll('.chip');
  if (!chips.length) return;
  var cards = document.querySelectorAll('.card[data-tags]');
  chips.forEach(function (c) {
    c.addEventListener('click', function () {
      chips.forEach(function (x) { x.setAttribute('aria-pressed', x === c); });
      var t = c.dataset.tag;
      cards.forEach(function (card) { card.hidden = t !== 'all' && card.dataset.tags.indexOf(t) < 0; });
    });
  });
})();

// Tools: bug report writer
(function () {
  var f = document.getElementById('bug-form');
  if (!f) return;
  var out = document.getElementById('bug-out'), copy = document.getElementById('copy');
  function v(n) { return f.elements[n].value.trim() || '(not filled in)'; }
  function render() {
    var s = f.elements.steps.value.trim();
    var steps = s ? s.split('\n').filter(Boolean).map(function (l, i) { return (i + 1) + '. ' + l.replace(/^\d+[.)]\s*/, ''); }).join('\n') : '(not filled in)';
    out.textContent = v('title') + '\n\nSeverity: ' + f.elements.severity.value + '\nEnvironment: ' + v('env') +
      '\n\nSteps to reproduce:\n' + steps + '\n\nExpected result:\n' + v('expected') + '\n\nActual result:\n' + v('actual');
  }
  f.addEventListener('input', render);
  f.addEventListener('submit', function (e) { e.preventDefault(); });
  render();
  copy.addEventListener('click', function () {
    if (!navigator.clipboard) return;
    navigator.clipboard.writeText(out.textContent).then(function () {
      copy.textContent = 'Copied';
      setTimeout(function () { copy.textContent = 'Copy report'; }, 1500);
    });
  });
})();

// Contact: quick checks in the browser. The servlet validates again on the server.
(function () {
  var form = document.getElementById('contact-form');
  if (!form) return;
  var box = document.getElementById('form-error');
  form.addEventListener('submit', function (e) {
    var problems = [];
    if (!form.name.value.trim()) problems.push('Enter your name.');
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email.value.trim())) problems.push('Enter a valid email address.');
    if (form.message.value.trim().length < 10) problems.push('Write a message of at least 10 characters.');
    if (problems.length) { e.preventDefault(); box.textContent = problems.join(' '); box.hidden = false; }
    else box.hidden = true;
  });
})();

// Play: Bug Squash game
(function () {
  var arena = document.getElementById('arena');
  if (!arena) return;
  var scoreEl = document.getElementById('score'), timeEl = document.getElementById('time'),
      bestEl = document.getElementById('best'), startBtn = document.getElementById('start');
  var cells = [], best = 0, score = 0, left = 30, tick, spawn, active = -1;
  try { best = +localStorage.getItem('best') || 0; } catch (e) {}
  bestEl.textContent = best;
  for (var i = 0; i < 12; i++) {
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'cell'; b.disabled = true; b.setAttribute('aria-label', 'Empty square');
    arena.appendChild(b); cells.push(b);
  }
  function clearBug() {
    if (active >= 0) { cells[active].textContent = ''; cells[active].classList.remove('bug'); cells[active].setAttribute('aria-label', 'Empty square'); }
    active = -1;
  }
  function showBug() {
    clearBug();
    active = Math.floor(Math.random() * cells.length);
    cells[active].textContent = '\uD83D\uDC1E'; cells[active].classList.add('bug'); cells[active].setAttribute('aria-label', 'Bug, squash it');
  }
  cells.forEach(function (c, idx) {
    c.addEventListener('click', function () {
      if (idx === active) { score++; scoreEl.textContent = score; showBug(); }
    });
  });
  function end() {
    clearInterval(tick); clearInterval(spawn); clearBug();
    cells.forEach(function (c) { c.disabled = true; });
    startBtn.disabled = false; startBtn.textContent = 'Play again';
    if (score > best) { best = score; bestEl.textContent = best; try { localStorage.setItem('best', best); } catch (e) {} }
  }
  startBtn.addEventListener('click', function () {
    score = 0; left = 30; scoreEl.textContent = 0; timeEl.textContent = 30;
    cells.forEach(function (c) { c.disabled = false; });
    startBtn.disabled = true; showBug();
    spawn = setInterval(showBug, 900);
    tick = setInterval(function () { left--; timeEl.textContent = left; if (left <= 0) end(); }, 1000);
  });
})();

// Play: JARVIS-lite command box (a demo with fixed answers, not a real AI)
(function () {
  var form = document.getElementById('term-form');
  if (!form) return;
  var out = document.getElementById('term-out'), inp = document.getElementById('term-in');
  var jokes = [
    "A QA engineer walks into a bar. Orders 1 beer, 0 beers, 99999 beers, -1 beers and a lizard.",
    "There are 10 kinds of people: those who understand binary and those who don't.",
    "It works on my machine.",
    "A programmer's partner says: go to the shop, buy milk, and if they have eggs, buy 6. He came back with 6 milks."
  ];
  var cmds = {
    help: function () { return "Commands: about, skills, projects, games, joke, time, theme, clear"; },
    hello: function () { return "Hello! I'm a small demo, not a real AI."; },
    about: function () { return "Andrei Costin. I test software and write code, and I'm looking for part-time, remote work."; },
    skills: function () { return "Java, Python, HTML/CSS/JS and debugging. Learning C and C++."; },
    projects: function () { return "Web games, console games, a schedule app in Java, PYRO and a JARVIS-style AI assistant. See the Projects page."; },
    games: function () { return "Try Bug Squash above."; },
    joke: function () { return jokes[Math.floor(Math.random() * jokes.length)]; },
    time: function () { return new Date().toLocaleTimeString(); }
  };
  function print(t, cls) {
    var p = document.createElement('p'); p.textContent = t; if (cls) p.className = cls;
    out.appendChild(p); out.scrollTop = out.scrollHeight;
  }
  print("JARVIS-lite is online. Type help.");
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var q = inp.value.trim().toLowerCase(); inp.value = '';
    if (!q) return;
    print('> ' + q, 'me');
    if (q === 'clear') { out.textContent = ''; return; }
    if (q === 'theme') { var t = document.getElementById('theme'); if (t) t.click(); print("Theme switched."); return; }
    if (Object.prototype.hasOwnProperty.call(cmds, q)) print(cmds[q]());
    else print("I don't know \"" + q + "\" yet. Type help.");
  });
})();

// Cinematic effects: reveal on scroll, animated counters, hero parallax
(function () {
  var reduce = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  var items = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && !reduce) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { threshold: 0.15 });
    items.forEach(function (el) { io.observe(el); });
  } else items.forEach(function (el) { el.classList.add('in'); });

  document.querySelectorAll('[data-count]').forEach(function (el) {
    var n = +el.dataset.count;
    if (reduce || !('IntersectionObserver' in window)) { el.textContent = n; return; }
    el.textContent = 0;
    new IntersectionObserver(function (es, o) {
      if (!es[0].isIntersecting) return;
      o.disconnect();
      var t0 = null;
      (function step(t) {
        if (t0 === null) t0 = t;
        var p = Math.min((t - t0) / 1200, 1);
        el.textContent = Math.round(n * p);
        if (p < 1) requestAnimationFrame(step);
      })(performance.now());
    }).observe(el);
  });

  var imgs = document.querySelectorAll('.hero-img');
  if (imgs.length && !reduce) {
    var busy = false;
    window.addEventListener('scroll', function () {
      if (busy) return; busy = true;
      requestAnimationFrame(function () {
        var y = window.scrollY;
        imgs.forEach(function (im) { im.style.transform = 'translate3d(0,' + (y * 0.25) + 'px,0)'; });
        busy = false;
      });
    }, { passive: true });
  }
})();
