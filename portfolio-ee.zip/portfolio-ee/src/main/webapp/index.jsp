<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Home"/><c:set var="active" value="home"/><c:set var="hero" value="https://images.unsplash.com/photo-1515868769-ad822a0c67e9?auto=format&fit=crop&w=1800&q=70"/>
<%@ include file="/WEB-INF/jspf/header.jspf" %>
<div class="hero tall">
  <img class="hero-img" src="${hero}" alt="">
  <div class="hero-text">
    <p class="scene">A QA engineer story</p>
    <h1>Andrei Costin</h1>
    <p class="lead">QA engineer, developer and game builder. I break your software before your users do, then show exactly how.</p>
    <p><a class="btn" href="${pageContext.request.contextPath}/contact">Hire me for a small job</a> <a class="btn line" href="${pageContext.request.contextPath}/projects">Watch the projects</a></p>
  </div>
</div>
<div class="marq" aria-hidden="true"><div>JAVA &bull; PYTHON &bull; JAVASCRIPT &bull; HTML &bull; CSS &bull; SERVLETS &bull; JSP &bull; QA TESTING &bull; DEBUGGING &bull; GAMES &bull; AI ASSISTANT &bull; JAVA &bull; PYTHON &bull; JAVASCRIPT &bull; HTML &bull; CSS &bull; SERVLETS &bull; JSP &bull; QA TESTING &bull; DEBUGGING &bull; GAMES &bull; AI ASSISTANT</div></div>
<main class="wrap">
  <p class="scene reveal">Scene 01 &mdash; The test run</p>
  <div class="run reveal" aria-live="polite">
    <div class="run-head"><strong>Skills test run</strong><button id="go" type="button">Run tests</button></div>
    <ul id="tests">
      <li data-r="pass"><span>Java: classes, collections, servlets and JSP</span><span>waiting</span></li>
      <li data-r="pass"><span>Python: scripts and automation</span><span>waiting</span></li>
      <li data-r="pass"><span>HTML, CSS and JavaScript pages</span><span>waiting</span></li>
      <li data-r="pass"><span>Debugging: find, isolate, report</span><span>waiting</span></li>
      <li data-r="learn"><span>C and C++</span><span>waiting</span></li>
    </ul>
  </div>
  <p class="note">The red result is honest: C and C++ are what I'm learning right now.</p>
  <div class="stats reveal">
    <div><strong data-count="5">5</strong><span>projects built</span></div>
    <div><strong data-count="3">3</strong><span>courses finished</span></div>
    <div><strong data-count="3">3</strong><span>languages spoken</span></div>
  </div>
</main>
<section class="band">
  <img class="band-img" src="https://images.unsplash.com/photo-1585412168334-8fa91429cc64?auto=format&fit=crop&w=1800&q=70" alt="">
  <div class="reveal"><p class="scene">Scene 02 &mdash; The mission</p><h2 class="big">I break it before they do.</h2></div>
</section>
<main class="wrap">
  <p class="scene reveal">Scene 03 &mdash; What I can do for you</p>
  <div class="grid3">
    <div class="card reveal"><h3>Test your website</h3><p>I try your forms and pages on phone and desktop and send you a clear list of what breaks.</p></div>
    <div class="card reveal"><h3>Fix a bug</h3><p>Send me the error and the code. I find the cause and explain the fix.</p></div>
    <div class="card reveal"><h3>Build a small site</h3><p>A simple, fast page for a shop, a service or an event.</p></div>
  </div>
  <p class="scene reveal">Scene 04 &mdash; Now showing</p>
  <div class="grid3">
    <div class="card reveal"><h3>Web games</h3><p>Games that run in the browser, built with HTML, CSS and JavaScript.</p></div>
    <div class="card reveal"><h3>Schedule app</h3><p>An application written in Java for planning a schedule.</p></div>
    <div class="card reveal"><h3>JARVIS-style AI assistant</h3><p>My own AI assistant project, inspired by JARVIS.</p></div>
  </div>
  <p class="reveal"><a class="btn line-dark" href="${pageContext.request.contextPath}/projects">All projects</a> <a class="btn line-dark" href="${pageContext.request.contextPath}/play.jsp">Play a game</a></p>
</main>
<section class="band short">
  <img class="band-img" src="https://images.unsplash.com/photo-1709054952884-0fb6108f1df1?auto=format&fit=crop&w=1800&q=70" alt="">
  <div class="reveal"><h2 class="big">Need a tester?</h2><p><a class="btn" href="${pageContext.request.contextPath}/contact">Let's talk</a></p></div>
</section>
<%@ include file="/WEB-INF/jspf/footer.jspf" %>
