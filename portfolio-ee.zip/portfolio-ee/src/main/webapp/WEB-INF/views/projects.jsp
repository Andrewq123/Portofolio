<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Projects"/><c:set var="active" value="projects"/><c:set var="hero" value="https://images.unsplash.com/photo-1709054952884-0fb6108f1df1?auto=format&fit=crop&w=1800&q=70"/>
<%@ include file="/WEB-INF/jspf/header.jspf" %>
<div class="hero">
  <img class="hero-img" src="${hero}" alt="">
  <div class="hero-text"><h1>Projects</h1><p class="lead">Games, apps and an AI assistant I built, and what I'm building next.</p></div>
</div>
<main class="wrap">
  <div class="chips" role="group" aria-label="Filter projects">
    <button type="button" class="chip" data-tag="all" aria-pressed="true">All</button>
    <button type="button" class="chip" data-tag="Games" aria-pressed="false">Games</button>
    <button type="button" class="chip" data-tag="Java" aria-pressed="false">Java</button>
    <button type="button" class="chip" data-tag="AI" aria-pressed="false">AI</button>
    <button type="button" class="chip" data-tag="QA" aria-pressed="false">QA</button>
    <button type="button" class="chip" data-tag="Python" aria-pressed="false">Python</button>
  </div>
  <div class="projects">
<%-- LOOP --%>
    <c:forEach var="p" items="${projects}">
      <article class="card" data-tags="<c:forEach var='t' items='${p.tags}'><c:out value='${t}'/>|</c:forEach>">
        <h3><c:out value="${p.title}"/><c:if test="${not empty p.year}"> <span class="year"><c:out value="${p.year}"/></span></c:if></h3>
        <p><c:out value="${p.summary}"/></p>
        <p class="tags"><c:forEach var="t" items="${p.tags}"><span><c:out value="${t}"/></span></c:forEach></p>
        <span class="status"><c:out value="${p.status}"/></span>
      </article>
    </c:forEach>
<%-- ENDLOOP --%>
  </div>
</main>
<%@ include file="/WEB-INF/jspf/footer.jspf" %>
