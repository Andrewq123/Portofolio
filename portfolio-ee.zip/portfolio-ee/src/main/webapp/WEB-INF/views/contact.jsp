<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Contact"/><c:set var="active" value="contact"/><c:set var="hero" value="https://images.unsplash.com/photo-1515868769-ad822a0c67e9?auto=format&fit=crop&w=1800&q=70"/>
<%@ include file="/WEB-INF/jspf/header.jspf" %>
<div class="hero">
  <img class="hero-img" src="${hero}" alt="">
  <div class="hero-text"><h1>Contact</h1><p class="lead">Need something tested or a small site built? Send me a message.</p></div>
</div>
<main class="wrap">
<c:if test="${not empty flash}"><p class="ok" role="status"><c:out value="${flash}"/></p></c:if>
<c:if test="${not empty errors}">
  <ul class="err" role="alert"><c:forEach var="e" items="${errors}"><li><c:out value="${e}"/></li></c:forEach></ul>
</c:if>
  <form id="contact-form" method="post" action="${pageContext.request.contextPath}/contact" novalidate>
    <label for="name">Name</label>
    <input id="name" name="name" maxlength="80" required value="<c:out value='${param.name}'/>">
    <label for="email">Email</label>
    <input id="email" name="email" type="email" maxlength="120" required value="<c:out value='${param.email}'/>">
    <label for="message">Message</label>
    <textarea id="message" name="message" rows="6" maxlength="1000" required><c:out value="${param.message}"/></textarea>
    <p id="form-error" class="err" role="alert" hidden></p>
    <button type="submit">Send message</button>
  </form>
</main>
<%@ include file="/WEB-INF/jspf/footer.jspf" %>
