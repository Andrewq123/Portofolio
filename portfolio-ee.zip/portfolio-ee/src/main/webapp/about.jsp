<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="About"/><c:set var="active" value="about"/><c:set var="hero" value="https://images.unsplash.com/photo-1542831371-29b0f74f9713?auto=format&fit=crop&w=1800&q=70"/>
<%@ include file="/WEB-INF/jspf/header.jspf" %>
<div class="hero">
  <img class="hero-img" src="${hero}" alt="">
  <div class="hero-text"><p class="scene">The story so far</p><h1>About</h1>
    <p class="lead">I study programming and software testing, and I'm looking for part-time, remote work or small testing and coding jobs.</p></div>
</div>
<main class="wrap">
  <p class="scene reveal">Chapter 01 &mdash; Timeline</p>
  <ol class="tl">
    <li class="reveal"><b>2023</b><br>Finished my HTML, CSS and JavaScript course (IUCOSOFT). Started making web games.</li>
    <li class="reveal"><b>2024</b><br>Finished my Java course (IUCOSOFT). Built console games and a schedule app.</li>
    <li class="reveal"><b>2025</b><br>Finished my Python course (Code Academy). Worked on PYRO and my JARVIS-style AI assistant.</li>
    <li class="reveal"><b>Now</b><br>Studying programming and software testing, learning C and C++, and building this portfolio.</li>
  </ol>
  <p class="note">The dates for each project are my best fit with my course years. I'll correct them on the Projects page.</p>
  <p class="scene reveal">Chapter 02 &mdash; Training</p>
  <dl class="reveal">
    <div><dt>Programming and software testing</dt><dd>Colegiul Universității Tehnice a Moldovei, in progress</dd></div>
    <div><dt>Python</dt><dd>Code Academy, finished 2025</dd></div>
    <div><dt>Java</dt><dd>IUCOSOFT, finished 2024</dd></div>
    <div><dt>HTML, CSS, JavaScript</dt><dd>IUCOSOFT, finished 2023</dd></div>
  </dl>
  <p class="scene reveal">Chapter 03 &mdash; Details</p>
  <dl class="reveal">
    <div><dt>Languages</dt><dd>Romanian (native), English (fluent), Russian (elementary)</dd></div>
    <div><dt>Looking for</dt><dd>Part-time, remote or mobile work</dd></div>
  </dl>
</main>
<%@ include file="/WEB-INF/jspf/footer.jspf" %>
