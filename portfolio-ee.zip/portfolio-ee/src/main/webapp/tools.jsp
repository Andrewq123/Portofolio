<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Tools"/><c:set var="active" value="tools"/><c:set var="hero" value="https://images.unsplash.com/photo-1515879218367-8466d910aaa4?auto=format&fit=crop&w=1800&q=70"/>
<%@ include file="/WEB-INF/jspf/header.jspf" %>
<div class="hero">
  <img class="hero-img" src="${hero}" alt="">
  <div class="hero-text"><h1>Tools</h1><p class="lead">A bug report writer. Fill in the form and copy a clean report to paste into any tracker.</p></div>
</div>
<main class="wrap">
  <div class="split">
    <form id="bug-form" novalidate>
      <label for="title">Title</label><input id="title" name="title" maxlength="120">
      <label for="severity">Severity</label>
      <select id="severity" name="severity"><option>Low</option><option selected>Medium</option><option>High</option><option>Critical</option></select>
      <label for="env">Environment</label><input id="env" name="env" placeholder="Chrome 126, Android 14">
      <label for="steps">Steps (one per line)</label><textarea id="steps" name="steps" rows="4"></textarea>
      <label for="expected">Expected result</label><textarea id="expected" name="expected" rows="2"></textarea>
      <label for="actual">Actual result</label><textarea id="actual" name="actual" rows="2"></textarea>
    </form>
    <div>
      <div class="run-head plain"><strong>Your report</strong><button id="copy" type="button">Copy report</button></div>
      <pre id="bug-out" class="out" aria-live="polite"></pre>
    </div>
  </div>
</main>
<%@ include file="/WEB-INF/jspf/footer.jspf" %>
