# Portfolio: Java EE (Jakarta EE 10) + JSP + Servlets

Needs: JDK 17+, Maven 3.9+, Apache Tomcat 10.1 (Tomcat 9 will NOT work: it uses the old javax.* package names).

1. `mvn clean package`  -> creates `target/portfolio.war`
2. Copy `portfolio.war` into Tomcat's `webapps/` folder and start Tomcat (`bin/startup.sh` or `bin/startup.bat`)
3. Open http://localhost:8080/portfolio/

Structure
- `src/main/java/.../*Servlet.java`  controllers (/projects, /contact)
- `src/main/java/.../Project*.java`  model and in-memory data
- `src/main/webapp/*.jsp`            public pages (home, about)
- `src/main/webapp/WEB-INF/views`    pages only reachable through a servlet
- `src/main/webapp/WEB-INF/jspf`     shared header and footer
- `src/main/webapp/css, js`          separate stylesheet and script

Extras
- `ViewCounterFilter` counts page views and the footer shows the number (resets when Tomcat restarts).
- Photos are loaded from Unsplash (needs internet). Credits are in the footer.
- Tools page: bug report writer. Cinematic style: scroll reveals, counters, parallax, grain, "Lights on" button for light mode.
- Projects: edit `ProjectRepository.java` and put the real year in each project (4th argument). Empty "" hides the year.
- Play page: Bug Squash game (best score kept in the browser) and a JARVIS-lite command box with fixed answers.
